/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloVo;

/**
 *
 * @author juans
 */
public class actividadAprendizajeVo {
        private String idAcApre, nomAcApre, dia, horaIni, horaFin, idAsoComp, nomComp;

    public actividadAprendizajeVo() {
    }

    public actividadAprendizajeVo(String idAcApre, String nomAcApre, String dia, String horaIni, String horaFin, String idAsoComp, String nomComp) {
        this.idAcApre = idAcApre;
        this.nomAcApre = nomAcApre;
        this.dia = dia;
        this.horaIni = horaIni;
        this.horaFin = horaFin;
        this.idAsoComp = idAsoComp;
        this.nomComp = nomComp;
    }
    
    public actividadAprendizajeVo(String idAcApre, String nomAcApre, String dia, String horaIni, String horaFin, String idAsoComp) {
        this.idAcApre = idAcApre;
        this.nomAcApre = nomAcApre;
        this.dia = dia;
        this.horaIni = horaIni;
        this.horaFin = horaFin;
        this.idAsoComp = idAsoComp;
    }

    public String getIdAcApre() {
        return idAcApre;
    }

    public void setIdAcApre(String idAcApre) {
        this.idAcApre = idAcApre;
    }

    public String getNomAcApre() {
        return nomAcApre;
    }

    public void setNomAcApre(String nomAcApre) {
        this.nomAcApre = nomAcApre;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getHoraIni() {
        return horaIni;
    }

    public void setHoraIni(String horaIni) {
        this.horaIni = horaIni;
    }

    public String getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(String horaFin) {
        this.horaFin = horaFin;
    }

    public String getIdAsoComp() {
        return idAsoComp;
    }

    public void setIdAsoComp(String idAsoComp) {
        this.idAsoComp = idAsoComp;
    }

    public String getNomComp() {
        return nomComp;
    }

    public void setNomComp(String nomComp) {
        this.nomComp = nomComp;
    }

  
}
