/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloVo;

/**
 *
 * @author juans
 */
public class asociacionUsuariosVo {
     private String idAsoUsu ,idFicha, numDoc ;

    public asociacionUsuariosVo() {
    }

    public asociacionUsuariosVo(String idAsoUsu, String idFicha, String numDoc) {
        this.idAsoUsu = idAsoUsu;
        this.idFicha = idFicha;
        this.numDoc = numDoc;
    }

    public String getIdAsoUsu() {
        return idAsoUsu;
    }

    public void setIdAsoUsu(String idAsoUsu) {
        this.idAsoUsu = idAsoUsu;
    }

    public String getIdFicha() {
        return idFicha;
    }

    public void setIdFicha(String idFicha) {
        this.idFicha = idFicha;
    }

    public String getNumDoc() {
        return numDoc;
    }

    public void setNumDoc(String numDoc) {
        this.numDoc = numDoc;
    }

   
}
