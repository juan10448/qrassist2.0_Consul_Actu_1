/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloVo;

/**
 *
 * @author User
 */
public class asociacionCompetenciasVo {
    
    private String idAsoComp, idFicha, idComp, nomComp, numDoc;

    public asociacionCompetenciasVo() {
    }

    
    
    public asociacionCompetenciasVo(String idAsoComp, String idFicha, String idComp, String nomComp, String numDoc) {
        this.idAsoComp = idAsoComp;
        this.idFicha = idFicha;
        this.idComp = idComp;
        this.nomComp = nomComp;
        this.numDoc = numDoc;
    }
    public asociacionCompetenciasVo(String idAsoComp, String idFicha, String idComp, String numDoc) {
        this.idAsoComp = idAsoComp;
        this.idFicha = idFicha;
        this.idComp = idComp;
        this.numDoc = numDoc;
    }

    public String getIdAsoComp() {
        return idAsoComp;
    }

    public void setIdAsoComp(String idAsoComp) {
        this.idAsoComp = idAsoComp;
    }

    public String getIdFicha() {
        return idFicha;
    }

    public void setIdFicha(String idFicha) {
        this.idFicha = idFicha;
    }

    public String getIdComp() {
        return idComp;
    }

    public void setIdComp(String idComp) {
        this.idComp = idComp;
    }

    public String getNomComp() {
        return nomComp;
    }

    public void setNomComp(String nomComp) {
        this.nomComp = nomComp;
    }

    public String getNumDoc() {
        return numDoc;
    }

    public void setNumDoc(String numDoc) {
        this.numDoc = numDoc;
    }
    
  
    
    
}
