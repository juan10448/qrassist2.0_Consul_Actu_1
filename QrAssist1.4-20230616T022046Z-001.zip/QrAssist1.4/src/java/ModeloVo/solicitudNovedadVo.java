/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloVo;

/**
 *
 * @author User
 */
public class solicitudNovedadVo {
    
    private String idnov, asunto, conte, idEstaSo, estado, idFicha;

    public solicitudNovedadVo() {
    }

    public solicitudNovedadVo(String idnov, String asunto, String conte, String idEstaSo, String estado, String idFicha) {
        this.idnov = idnov;
        this.asunto = asunto;
        this.conte = conte;
        this.idEstaSo = idEstaSo;
        this.estado = estado;
        this.idFicha = idFicha;
    }

    public solicitudNovedadVo(String idnov, String asunto, String conte, String idEstaSo, String idFicha) {
        this.idnov = idnov;
        this.asunto = asunto;
        this.conte = conte;
        this.idEstaSo = idEstaSo;
        this.idFicha = idFicha;
    }

    public String getIdnov() {
        return idnov;
    }

    public void setIdnov(String idnov) {
        this.idnov = idnov;
    }

    public String getAsunto() {
        return asunto;
    }

    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }

    public String getConte() {
        return conte;
    }

    public void setConte(String conte) {
        this.conte = conte;
    }

    public String getIdEstaSo() {
        return idEstaSo;
    }

    public void setIdEstaSo(String idEstaSo) {
        this.idEstaSo = idEstaSo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getIdFicha() {
        return idFicha;
    }

    public void setIdFicha(String idFicha) {
        this.idFicha = idFicha;
    }

   

}
