/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloVo;

/**
 *
 * @author juans
 */
public class novedadesVo {
private String idNov, horaFir, idAcApre, idTipoNov,nomAcApre, nomTipoNov , numDoc;

    public novedadesVo(String idNov, String horaFir, String idAcApre, String idTipoNov, String nomAcApre, String nomTipoNov, String numDoc) {
        this.idNov = idNov;
        this.horaFir = horaFir;
        this.idAcApre = idAcApre;
        this.idTipoNov = idTipoNov;
        this.nomAcApre = nomAcApre;
        this.nomTipoNov = nomTipoNov;
        this.numDoc = numDoc;
    }

    public novedadesVo(String idNov, String horaFir, String idAcApre, String idTipoNov, String numDoc) {
        this.idNov = idNov;
        this.horaFir = horaFir;
        this.idAcApre = idAcApre;
        this.idTipoNov = idTipoNov;
        this.numDoc = numDoc;
    }

    public novedadesVo() {
    }

    public String getIdNov() {
        return idNov;
    }

    public void setIdNov(String idNov) {
        this.idNov = idNov;
    }

    public String getHoraFir() {
        return horaFir;
    }

    public void setHoraFir(String horaFir) {
        this.horaFir = horaFir;
    }

    public String getIdAcApre() {
        return idAcApre;
    }

    public void setIdAcApre(String idAcApre) {
        this.idAcApre = idAcApre;
    }

    public String getIdTipoNov() {
        return idTipoNov;
    }

    public void setIdTipoNov(String idTipoNov) {
        this.idTipoNov = idTipoNov;
    }

    public String getNumDoc() {
        return numDoc;
    }

    public void setNumDoc(String numDoc) {
        this.numDoc = numDoc;
    }

    public String getNomAcApre() {
        return nomAcApre;
    }

    public void setNomAcApre(String nomAcApre) {
        this.nomAcApre = nomAcApre;
    }

    public String getNomTipoNov() {
        return nomTipoNov;
    }

    public void setNomTipoNov(String nomTipoNov) {
        this.nomTipoNov = nomTipoNov;
    }
    
    
    

    
}
