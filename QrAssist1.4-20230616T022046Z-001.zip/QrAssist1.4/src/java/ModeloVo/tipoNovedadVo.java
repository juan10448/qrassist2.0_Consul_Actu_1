/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloVo;

/**
 *
 * @author juans
 */
public class tipoNovedadVo {
        private String idTipoNov, nomTipoNov;

    public tipoNovedadVo() {
    }

    public tipoNovedadVo(String idTipoNov, String nomTipoNov) {
        this.idTipoNov = idTipoNov;
        this.nomTipoNov = nomTipoNov;
    }

    public String getIdTipoNov() {
        return idTipoNov;
    }

    public void setIdTipoNov(String idTipoNov) {
        this.idTipoNov = idTipoNov;
    }

    public String getNomTipoNov() {
        return nomTipoNov;
    }

    public void setNomTipoNov(String nomTipoNov) {
        this.nomTipoNov = nomTipoNov;
    }

    
}
