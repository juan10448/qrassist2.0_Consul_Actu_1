/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloVo;

/**
 *
 * @author User
 */
public class estadosSolicitudesVo {

    private String idEstaSo, nomEstaSo;

    public estadosSolicitudesVo() {
    }

    public estadosSolicitudesVo(String idEstaSo, String nomEstaSo) {
        this.idEstaSo = idEstaSo;
        this.nomEstaSo = nomEstaSo;
    }
    
    

    public String getIdEstaSo() {
        return idEstaSo;
    }

    public void setIdEstaSo(String idEstaSo) {
        this.idEstaSo = idEstaSo;
    }

    public String getNomEstaSo() {
        return nomEstaSo;
    }

    public void setNomEstaSo(String nomEstaSo) {
        this.nomEstaSo = nomEstaSo;
    }

}
