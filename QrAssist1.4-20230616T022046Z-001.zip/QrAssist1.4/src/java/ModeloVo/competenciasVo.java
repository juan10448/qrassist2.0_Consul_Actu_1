/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloVo;

/**
 *
 * @author juans
 */
public class competenciasVo {
    private String idComp, nomComp ;

    public competenciasVo() {
    }

    public competenciasVo(String idComp, String nomComp) {
        this.idComp = idComp;
        this.nomComp = nomComp;
    }

    public String getIdComp() {
        return idComp;
    }

    public void setIdComp(String idComp) {
        this.idComp = idComp;
    }

    public String getNomComp() {
        return nomComp;
    }

    public void setNomComp(String nomComp) {
        this.nomComp = nomComp;
    }

    
    
     
}
