/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import ModeloDao.novedadesDao;
import ModeloVo.novedadesVo;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author juans
 */
@WebServlet(name = "novedadesControlador", urlPatterns = {"/novedades"})
public class novedadesControlador extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String idNov = request.getParameter("idNov");
        String horaFir = request.getParameter("horaFir");
        String idAcApre  = request.getParameter("idAcApre");
        String idTipoNov = request.getParameter("idTipoNov");        
        String nomAcApre  = request.getParameter("nomAcApre");
        String nomTipoNov = request.getParameter("nomTipoNov");       
        String numDoc= request.getParameter("numDoc");
        
        
        
        int opcion = Integer.parseInt(request.getParameter("opcion"));
        
        novedadesVo novVo = new novedadesVo(idNov, horaFir, idAcApre, idTipoNov, nomAcApre, nomAcApre, numDoc);
        novedadesDao novDao = new novedadesDao(novVo);   
        switch(opcion){
            case 1://agregar
                if (novDao.agregar()) {
                    request.setAttribute("mensajeExito", "¡La Novedad Se Tomo  correctamente!");                    
                }else{
                    request.setAttribute("mensajeError", "¡La Novedad no Se logro tomar!");
                }
                request.getRequestDispatcher("registroNovedad.jsp").forward(request, response);
                break;
                
            case 2://actualizar
                if (novDao.actualizar()) {
                    request.setAttribute("mensajeExito", "¡La Novedad se actualizo correctamente!");
                }else{
                    request.setAttribute("mensajeError", "¡La Novedad no se logro actualizar!");
                }
                request.getRequestDispatcher("consultarNovedad.jsp").forward(request, response);
                
                case 3: //Consultar Id  
                   novVo = novDao.consultarNovedadDocumento(numDoc);
                   if(novVo != null){ 
                   request.setAttribute("NovedadEncontrada", novVo);
                   request.getRequestDispatcher("actualizarNovedad.jsp").forward(request, response);
                   break;
                   }else{
                   request.setAttribute("MensajeError", "La Novedad No existe");
                   request.getRequestDispatcher("consultarNovedad.jsp").forward(request, response);
                   } break;    
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
