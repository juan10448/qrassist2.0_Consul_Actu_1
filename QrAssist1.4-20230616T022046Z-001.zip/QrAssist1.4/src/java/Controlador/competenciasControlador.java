/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import ModeloDao.competenciasDao;
import ModeloVo.competenciasVo;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author juans
 */
@WebServlet(name = "competenciasControlador", urlPatterns = {"/competencias"})
public class competenciasControlador extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String idComp = request.getParameter("idComp");
        String nomComp = request.getParameter("nomComp");
        int opcion = Integer.parseInt(request.getParameter("opcion"));
      
        competenciasVo compVo = new competenciasVo(idComp, nomComp);
        competenciasDao compDao = new competenciasDao(compVo);
   
        switch(opcion){
            case 1:
                if (compDao.agregar()) {
                    request.setAttribute("mensajeExito", "¡La Competencia se registro correctamente!");
                    
                }else{
                    request.setAttribute("mensajeError", "¡La Competencia NO se registro correctamente");
                }
                request.getRequestDispatcher("registroCompetencias.jsp").forward(request, response);
                break;
                
        case 2: 
                if (compDao.actualizar()) {
                    request.setAttribute("mensajeExito", "¡La Competencia se actualizo correctamente");
                }else{
                    request.setAttribute("mensajeError", "¡La Competencia NO se actualizo correctamente");
                }
                request.getRequestDispatcher("consultarCompetencia.jsp").forward(request, response);
                
            case 3: //Consultar Id  
                   compVo = compDao.consultarPorNombre(idComp);
                   if(compVo != null){ 
                   request.setAttribute("CompetenciaEncontrada", compVo);
                   request.getRequestDispatcher("actualizarCompetencias.jsp").forward(request, response);
                   break;
                   }else{
                   request.setAttribute("MensajeError", "La Competencia No existe");
                   request.getRequestDispatcher("consultarCompetencia.jsp").forward(request, response);
                   } break;        
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
