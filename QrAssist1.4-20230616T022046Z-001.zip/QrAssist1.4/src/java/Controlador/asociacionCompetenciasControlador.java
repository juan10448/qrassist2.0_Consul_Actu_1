/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import ModeloDao.asociacionCompetenciasDao;
import ModeloVo.asociacionCompetenciasVo;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author juans
 */
@WebServlet(name = "asociacionCompetenciasControlador", urlPatterns = {"/asociacionCompetencias"})
public class asociacionCompetenciasControlador extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
          
        String idAsoComp = request.getParameter("idAsoComp");
        String idFicha = request.getParameter("idFicha");
        String idComp = request.getParameter("idComp");
        String nomComp = request.getParameter("nomComp");
        String numDoc = request.getParameter("numDoc");
        
        
        int opcion = Integer.parseInt(request.getParameter("opcion"));
      
              
        asociacionCompetenciasVo asoCoVo = new asociacionCompetenciasVo(idAsoComp, idFicha, idComp, nomComp, numDoc);
        asociacionCompetenciasDao asoCoDao = new asociacionCompetenciasDao(asoCoVo);
   
        switch(opcion){
            case 1:
                if (asoCoDao.agregar()) {
                    request.setAttribute("mensajeExito", "¡La asociacion con la Competencia se registro correctamente!");
                    
                }else{
                    request.setAttribute("mensajeError", "¡La asociacion con la Competencia no se resgistro correctamente");
                }
                request.getRequestDispatcher("registroAsociacionCompetencias.jsp").forward(request, response);
                break;
            case 2: 
                if (asoCoDao.actualizar()) {
                    request.setAttribute("mensajeExito", "¡La asociacion con la Competencia  se actualizo correctamente");
                }else{
                    request.setAttribute("mensajeError", "¡La asociacion con la Competencia  NO se actualizo correctamente");
                }
                request.getRequestDispatcher("consultarAsociacionCompetencias.jsp").forward(request, response);
                
            case 3: //Consultar ficha  
                   asoCoVo = asoCoDao.consultarAsociacionCompetenciasFichas(idFicha);
                   if(asoCoVo != null){ 
                   request.setAttribute("asociacionCompetenciaEncontrada", asoCoVo);
                   request.getRequestDispatcher("actualizarAsociacionCompetencias.jsp").forward(request, response);
                   break;
                   }else{
                   request.setAttribute("MensajeError", "La asociacion con la Competencia  No existe");
                   request.getRequestDispatcher("consultarAsociacionCompetencias.jsp").forward(request, response);
                   } break;        
        }
        }
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

