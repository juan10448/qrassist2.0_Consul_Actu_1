/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import ModeloDao.asociacionCompetenciasDao;
import ModeloDao.asociacionUsuariosDao;
import ModeloVo.asociacionCompetenciasVo;
import ModeloVo.asociacionUsuariosVo;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author juans
 */
@WebServlet(name = "asociacionUsuarioscontrolador", urlPatterns = {"/asociacionUsuarios"})
public class asociacionUsuarioscontrolador extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String idAsoUsu= request.getParameter("idAsoUsu");
        String idFicha = request.getParameter("idFicha");
        String numDoc = request.getParameter("numDoc");
        
        int opcion = Integer.parseInt(request.getParameter("opcion"));
      
              
        asociacionUsuariosVo asoUsVo = new asociacionUsuariosVo(idAsoUsu, idFicha, numDoc);
        asociacionUsuariosDao asoUsDao = new asociacionUsuariosDao(asoUsVo);
   
        switch(opcion){
            case 1:
                if (asoUsDao.agregar()) {
                    request.setAttribute("mensajeExito", "¡La asociacion con el Usuario se registro correctamente!");
                    
                }else{
                    request.setAttribute("mensajeError", "¡La asociacion con el Usuario no se resgistro correctamente");
                }
                request.getRequestDispatcher("registroAsociacionUsuarios.jsp").forward(request, response);
                break;
            case 2: 
                if (asoUsDao.actualizar()) {
                    request.setAttribute("mensajeExito", "¡La asociacion con el Usuario  se actualizo correctamente");
                }else{
                    request.setAttribute("mensajeError", "¡La asociacion con el Usuario  NO se actualizo correctamente");
                }
                request.getRequestDispatcher("consultarAsociacionUsuarios.jsp").forward(request, response);
                
            case 3: //Consultar documento  
                   asoUsVo = asoUsDao.consultarAsousua(numDoc);
                   if(asoUsVo != null){ 
                   request.setAttribute("asociacionUsuarioEncontrada", asoUsVo);
                   request.getRequestDispatcher("actualizarAsociacionUsuarios.jsp").forward(request, response);
                   break;
                   }else{
                   request.setAttribute("MensajeError", "La asociacion con el Usuario  No existe");
                   request.getRequestDispatcher("consultarAsociacionUsuarios.jsp").forward(request, response);
                   } break;        
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
