/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import ModeloDao.solicitudNovedadDao;
import ModeloVo.solicitudNovedadVo;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author User
 */
@WebServlet(name = "solicitudNovedadControlador", urlPatterns = {"/solicitudNovedad"})
public class solicitudNovedadControlador extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String idNov = request.getParameter("idNov");
        String asunto = request.getParameter("asunto");
        String conte  = request.getParameter("conte");
        String idEstaSo = request.getParameter("idEstaSo");
        String estado = request.getParameter("estado");
        String idFicha= request.getParameter("idFicha");
        int opcion = Integer.parseInt(request.getParameter("opcion"));
        
        solicitudNovedadVo solNovVO = new solicitudNovedadVo(idNov, asunto, conte, idEstaSo, idFicha);
        solicitudNovedadDao solNovDAO = new solicitudNovedadDao(solNovVO);
   
        switch(opcion){
            case 1:
                if (solNovDAO.agregar()) {
                    request.setAttribute("mensajeExito", "¡La solicitud se agrego correctamente!");
                    
                }else{
                    request.setAttribute("mensajeError", "¡La solicitud no se logro agregar!");
                }
                request.getRequestDispatcher("registrosolicitudNovedad.jsp").forward(request, response);
                break;
            case 2: 
                if (solNovDAO.actualizar()) {
                    request.setAttribute("mensajeExito", "¡La solicitud se actualizo correctamente!");
                }else{
                    request.setAttribute("mensajeError", "¡La solicitud no se logro actualizar!");
                }
                request.getRequestDispatcher("consultarSolicitudNovedad.jsp").forward(request, response);
                
                case 3: //Consultar Id  
                   solNovVO = solNovDAO.consultarNovedad(asunto);
                   if(solNovVO != null){ 
                   request.setAttribute("SolicitudNovedadEncontrada", solNovVO);
                   request.getRequestDispatcher("actualizarSolicitudNovedad.jsp").forward(request, response);
                   break;
                   }else{
                   request.setAttribute("MensajeError", "La Ficha No existe");
                   request.getRequestDispatcher("consultarSolicitudNovedad.jsp").forward(request, response);
                   } break;    
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
