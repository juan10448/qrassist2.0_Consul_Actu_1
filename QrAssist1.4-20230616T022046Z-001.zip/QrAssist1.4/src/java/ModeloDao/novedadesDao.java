/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloDao;

import ModeloVo.novedadesVo;
import Util.CRUD;
import Util.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.ArrayList;


/**
 *
 * @author juans
 */
public class novedadesDao extends ConexionBD implements CRUD{
    
    
    private Connection conexion;
    private PreparedStatement puente;
    private ResultSet mensajero;
    private boolean operacion = false;
    private String sql;
    private String idNov = "", horaFir = "", idAcApre = "", idTipoNov = "", nomAcApre="", nomTipoNov="",  numDoc ="";

    
    
    
    public novedadesDao() {
    }

    public novedadesDao(novedadesVo novVo) {

        super();

        try {
            conexion = this.obteneConexion();
            
            idNov = novVo.getIdNov();
            horaFir = novVo.getHoraFir();
            idAcApre = novVo.getIdAcApre();
            idTipoNov = novVo.getIdTipoNov();
            numDoc = novVo.getNumDoc();

        } catch (Exception e) {

            Logger.getLogger(novedadesDao.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    @Override
    public boolean agregar() {
        try {
            sql = "insert into novedades(horaFir,idAcApre,idTipoNov,numDoc) values (?,?,?,?)";
            puente = conexion.prepareStatement(sql);
            puente.setString(1, horaFir);
            puente.setString(2, idAcApre);
            puente.setString(3, idTipoNov);
            puente.setString(4, numDoc);
            puente.executeUpdate();
            operacion = true;
        } catch (Exception e) {
            Logger.getLogger(novedadesDao.class.getName()).log(Level.SEVERE, null, e);

        } finally {
            try {
                this.cerrarConexion();
            } catch (Exception e) {
                Logger.getLogger(novedadesDao.class.getName()).log(Level.SEVERE, null, e);
            }
        }
        return operacion;
    }

    @Override
    public boolean actualizar() {
    try 
        {
            sql = "update novedades set horaFir=?, idAcApre=?, idTipoNov=? where numDoc=?";
            puente = conexion.prepareStatement(sql);
            puente.setString(1, horaFir);
            puente.setString(2, idAcApre);
            puente.setString(3, idTipoNov);
            puente.setString(4, numDoc);   
            puente.executeUpdate();
            operacion = true;   
        } catch (Exception e)
        {
             Logger.getLogger(novedadesDao.class.getName()).log(Level.SEVERE,null,e);
        }finally{
            try {
                this.cerrarConexion();
            } catch (Exception e) {
                Logger.getLogger(novedadesDao.class.getName()).log(Level.SEVERE,null,e);
            }
        }
        return operacion;    
    }
    
     public novedadesVo consultarNovedadDocumento(String id){
         novedadesVo novVo = null;
         try {
             conexion = this.obteneConexion();
             sql="SELECT * FROM qrassist.vista_novedades where numDoc=?";
             puente =  conexion.prepareStatement(sql);
             puente.setString(1, id);
             mensajero = puente.executeQuery();
             while(mensajero.next()){
                 novVo = new novedadesVo(id, mensajero.getString(2), mensajero.getString(3), mensajero.getString(4),  mensajero.getString(5), mensajero.getString(6), mensajero.getString(7));
             }  
         } catch (Exception e) {
             Logger.getLogger(novedadesVo.class.getName()).log(Level.SEVERE, null,e);                   
         }finally{
                try {
                    this.cerrarConexion();
                } catch (Exception e) {
                    Logger.getLogger(novedadesVo.class.getName()).log(Level.SEVERE, null,e);             
                } 
                return novVo;
                  } 
    }
       
   public ArrayList<novedadesVo> Listar ( ){
       
          ArrayList<novedadesVo> ListarNovedades = new ArrayList<>();
         try {
             conexion = this.obteneConexion();
             sql="select * from vista_novedades";
             puente =  conexion.prepareStatement(sql);
             mensajero = puente.executeQuery();
              while (mensajero.next()) {                
                novedadesVo  novVo = new novedadesVo(mensajero.getString(1),mensajero.getString(2),mensajero.getString(3),mensajero.getString(4),mensajero.getString(5), mensajero.getString(6), mensajero.getString(7));
                ListarNovedades.add(novVo);           
            }
         } catch (Exception e) {
             Logger.getLogger(novedadesVo.class.getName()).log(Level.SEVERE, null,e);                   
         }finally{
                try {
                    this.cerrarConexion();
                } catch (Exception e) {
                    Logger.getLogger(novedadesVo.class.getName()).log(Level.SEVERE, null,e);             
                } 
                return ListarNovedades;
         }
    }
   
   
   
   

    @Override
    public boolean eliminar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
