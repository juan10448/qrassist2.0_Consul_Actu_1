/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloDao;

import ModeloVo.solicitudNovedadVo;
import Util.CRUD;
import Util.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class solicitudNovedadDao extends ConexionBD implements CRUD {

    private Connection conexion;
    private PreparedStatement puente;
    private ResultSet mensajero;
    private boolean operacion = false;
    private String sql;
    private String idNov = "", asunto = "", conte = "", idEstaSo = "", estado="", idFicha = "";

    public solicitudNovedadDao() {
    }

    public solicitudNovedadDao(solicitudNovedadVo SolNovVo) {

        super();

        try {
            conexion = this.obteneConexion();
            idNov = SolNovVo.getIdnov();
            asunto = SolNovVo.getAsunto();
            conte = SolNovVo.getConte();
            idEstaSo = SolNovVo.getIdEstaSo();
            estado = SolNovVo.getEstado();
            idFicha = SolNovVo.getIdFicha();

        } catch (Exception e) {

            Logger.getLogger(solicitudNovedadDao.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    @Override
    public boolean agregar() {
        try {
            sql = "insert into solicitudnovedad(asunto,conte,idEstaSo,idFicha) values (?,?,?,?)";
            puente = conexion.prepareStatement(sql);
            puente.setString(1, asunto);
            puente.setString(2, conte);
            puente.setString(3, idEstaSo);
            puente.setString(4, idFicha);
            puente.executeUpdate();
            operacion = true;
        } catch (Exception e) {
            Logger.getLogger(solicitudNovedadDao.class.getName()).log(Level.SEVERE, null, e);

        } finally {
            try {
                this.cerrarConexion();
            } catch (Exception e) {
                Logger.getLogger(solicitudNovedadDao.class.getName()).log(Level.SEVERE, null, e);
            }
        }
        return operacion;
    }

    @Override
    public boolean actualizar() {
    try 
        {
            sql = "update solicitudnovedad set conte=?, idEstaSo=?, idFicha=? where asunto=?";
            puente = conexion.prepareStatement(sql);
            puente.setString(1, conte);
            puente.setString(2, idEstaSo);
            puente.setString(3, idFicha);
            puente.setString(4, asunto);
            puente.executeUpdate();
            operacion = true;
     
        } catch (Exception e)
        {
             Logger.getLogger(solicitudNovedadDao.class.getName()).log(Level.SEVERE,null,e);
        }finally{
            try {
                this.cerrarConexion();
            } catch (Exception e) {
                Logger.getLogger(solicitudNovedadDao.class.getName()).log(Level.SEVERE,null,e);
            }
        }
        return operacion;    
    }
    
     public solicitudNovedadVo consultarNovedad(String id){
         solicitudNovedadVo solNoVo = null;
         try {
             conexion = this.obteneConexion();
             sql="select * from solicitudnovedad where asunto = ?";
             puente =  conexion.prepareStatement(sql);
             puente.setString(1, id);
             mensajero = puente.executeQuery();
             while(mensajero.next()){
                 solNoVo = new solicitudNovedadVo(id, mensajero.getString(2), mensajero.getString(3), mensajero.getString(4), mensajero.getString(5));
             }  
         } catch (Exception e) {
             Logger.getLogger(solicitudNovedadVo.class.getName()).log(Level.SEVERE, null,e);                   
         }finally{
                try {
                    this.cerrarConexion();
                } catch (Exception e) {
                    Logger.getLogger(solicitudNovedadVo.class.getName()).log(Level.SEVERE, null,e);             
                } 
                return solNoVo;
                  } 
    }
       
   public ArrayList<solicitudNovedadVo> Listar ( ){
       
          ArrayList<solicitudNovedadVo> ListarNovedades = new ArrayList<>();
         try {
             conexion = this.obteneConexion();
             sql="select * from vista_solicitud_novedad";
             puente =  conexion.prepareStatement(sql);
             mensajero = puente.executeQuery();
              while (mensajero.next()) {                
                solicitudNovedadVo  solNoVO = new solicitudNovedadVo(mensajero.getString(1),mensajero.getString(2),mensajero.getString(3),mensajero.getString(4),mensajero.getString(5), mensajero.getString(6));
                ListarNovedades.add(solNoVO);           
            }
         } catch (Exception e) {
             Logger.getLogger(solicitudNovedadVo.class.getName()).log(Level.SEVERE, null,e);                   
         }finally{
                try {
                    this.cerrarConexion();
                } catch (Exception e) {
                    Logger.getLogger(solicitudNovedadVo.class.getName()).log(Level.SEVERE, null,e);             
                } 
                return ListarNovedades;
         }
    }
   
   
   
   

    @Override
    public boolean eliminar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
 }


