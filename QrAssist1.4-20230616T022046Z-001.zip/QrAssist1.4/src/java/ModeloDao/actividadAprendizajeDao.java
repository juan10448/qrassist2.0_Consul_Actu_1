/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloDao;

import ModeloVo.actividadAprendizajeVo;
import Util.CRUD;
import Util.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author juans
 */
public class actividadAprendizajeDao  extends ConexionBD implements CRUD{
    private Connection conexion;
    private PreparedStatement puente;
    private ResultSet mensajero;
    private boolean operacion = false;
    private String sql;
    private String idAcApre ="", nomAcApre ="", dia="", horaIni="", horaFin="", idAsoComp="", nomComp="";

    public actividadAprendizajeDao() {
    }
    
    public actividadAprendizajeDao(actividadAprendizajeVo actiAprenvo)
    {
        super();
        try {
        conexion = this.obteneConexion();
        idAcApre = actiAprenvo.getIdAcApre();
        nomAcApre = actiAprenvo.getNomAcApre();
        dia = actiAprenvo.getDia();
        horaIni = actiAprenvo.getHoraIni();
        horaFin = actiAprenvo.getHoraFin();
        idAsoComp = actiAprenvo.getIdAsoComp();
        nomComp =  actiAprenvo.getNomComp();
            
        } catch (Exception e) {
        Logger.getLogger(actividadAprendizajeDao.class.getName()).log(Level.SEVERE, null, e);
        } 
    }
    
    @Override
    public boolean agregar() {
        try {
            sql =  "insert into actividadAprendizaje(nomAcApre, dia, horaIni, horaFin, idAsoComp) values (?,?,?,?,?)";
            puente = conexion.prepareCall(sql);
            puente.setString(1,nomAcApre);
            puente.setString(2,dia);
            puente.setString(3,horaIni);
            puente.setString(4,horaFin);
            puente.setString(5,idAsoComp);
            puente.executeUpdate();
            operacion = true;
            
        } catch (Exception e) {
             Logger.getLogger(actividadAprendizajeDao.class.getName()).log(Level.SEVERE, null, e);
        } finally {
            try {
                this.cerrarConexion();
            } catch (Exception e) {
                Logger.getLogger(actividadAprendizajeDao.class.getName()).log(Level.SEVERE, null, e);
            }
        }
        return operacion;
        }

    @Override
    public boolean actualizar() {
        try {

            sql = "update actividadAprendizaje set  nomAcApre =?, dia=?, horaIni=?, horaFin=?, idAsoComp=? where  idAcApre=?;";
            puente = conexion.prepareStatement(sql);
            puente.setString(1,nomAcApre);
            puente.setString(2,dia);
            puente.setString(3, horaIni);
            puente.setString(4, horaFin);
            puente.setString(5, idAsoComp);
            puente.setString(6,idAcApre);
            puente.executeUpdate();
            operacion = true;

        } catch (Exception e) {
            Logger.getLogger(actividadAprendizajeDao.class.getName()).log(Level.SEVERE, null, e);
        } finally {
            try {
                this.cerrarConexion();
            } catch (Exception e) {
                Logger.getLogger(actividadAprendizajeDao.class.getName()).log(Level.SEVERE, null, e);
            }
        }
        return operacion;
    }

    @Override
    public boolean eliminar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public actividadAprendizajeVo ConsultarPorNombre (String id)
    {
      actividadAprendizajeVo actAprVo = null;
        
        try {
            conexion = this.obteneConexion();
            sql="select * from actividadAprendizaje  where idAcApre =?";
            puente = conexion.prepareStatement(sql);
            puente.setString(1, id);
            mensajero = puente.executeQuery();
            while (mensajero.next()) {
              // posible error
                actAprVo = new actividadAprendizajeVo (id, mensajero.getString(2),mensajero.getString(3),mensajero.getString(4),mensajero.getString(5),mensajero.getString(6));
                
            }
            
        } catch (Exception e) {
             Logger.getLogger(actividadAprendizajeVo.class.getName()).log(Level.SEVERE, null,e);                   
         }finally{
                try {
                    this.cerrarConexion();
                } catch (Exception e) {
                    Logger.getLogger(actividadAprendizajeVo.class.getName()).log(Level.SEVERE, null,e);             
                } 
                return actAprVo;
                } 
        }
    public ArrayList<actividadAprendizajeVo> listar() {
        ArrayList<actividadAprendizajeVo> listarActividadAprendizaje = new ArrayList<>();

        try {
            conexion = this.obteneConexion();
            sql = "select * from vista_actividad_aprendizaje;";
            puente = conexion.prepareStatement(sql);
            mensajero = puente.executeQuery();
            while (mensajero.next()) {
               actividadAprendizajeVo actiAprenvo = new actividadAprendizajeVo (mensajero.getString(1), mensajero.getString(2),mensajero.getString(3),mensajero.getString(4),mensajero.getString(5),mensajero.getString(6), mensajero.getString(7));
               listarActividadAprendizaje.add(actiAprenvo);
            }
        } catch (Exception e) {
            Logger.getLogger(actividadAprendizajeVo.class.getName()).log(Level.SEVERE, null, e);
        } finally {
            try {
                this.cerrarConexion();

            } catch (Exception e) {
                Logger.getLogger(actividadAprendizajeVo.class.getName()).log(Level.SEVERE, null, e);
            }
            return listarActividadAprendizaje;
        }
    }
}
