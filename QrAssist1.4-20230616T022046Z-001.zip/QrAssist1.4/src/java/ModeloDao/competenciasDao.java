/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloDao;

import ModeloVo.competenciasVo;
import Util.CRUD;
import Util.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author juans
 */
public class competenciasDao extends ConexionBD implements CRUD {

    public competenciasDao() {
    }
    
    private Connection conexion;
    private PreparedStatement puente;
    private ResultSet mensajero;
    private boolean operacion = false;
    private String sql;
    private String idComp="", nomComp="";
    
   public competenciasDao(competenciasVo compVo) {

        super();
        try {
            conexion = this.obteneConexion();
            idComp = compVo.getIdComp();
            nomComp = compVo.getNomComp();
   
           
        } catch (Exception e) {
            Logger.getLogger(competenciasVo.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    @Override
    public boolean agregar() {
    try 
        {
            sql = "insert into competencias (nomComp) values (?)";
            puente = conexion.prepareStatement(sql);
            puente.setString(1, nomComp);
            puente.executeUpdate();
            operacion = true ;
        } catch (Exception e)
        {
            Logger.getLogger (competenciasDao.class.getName()).log(Level.SEVERE,null,e);

        }finally{
            try {
                this.cerrarConexion();
            } catch (Exception e) {
                Logger.getLogger(competenciasDao.class.getName()).log(Level.SEVERE,null,e);
            }
        }
        return operacion;    }

    @Override
    public boolean actualizar() {
    try 
        {
            sql = "update competencias set nomComp=? where idComp=?";
            puente = conexion.prepareStatement(sql);
            puente.setString(1, nomComp);
            puente.setString(2, idComp);
            puente.executeUpdate();
            operacion = true;  
        } catch (Exception e)
        {
             Logger.getLogger(competenciasDao.class.getName()).log(Level.SEVERE,null,e);
        }finally{
            try {
                this.cerrarConexion();
            } catch (Exception e) {
                Logger.getLogger(competenciasDao.class.getName()).log(Level.SEVERE,null,e);
            }
        }
        return operacion;    }

    @Override
    public boolean eliminar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
     public competenciasVo consultarPorNombre(String id){
         competenciasVo compVo = null;
         try {
             conexion = this.obteneConexion();
             sql="select * from competencias where idComp = ?";
             puente =  conexion.prepareStatement(sql);
             puente.setString(1, id);
             mensajero = puente.executeQuery();
             while(mensajero.next()){
                 compVo = new competenciasVo(id,mensajero.getString(2));
             }  
         } catch (Exception e) {
             Logger.getLogger(competenciasVo.class.getName()).log(Level.SEVERE, null,e);                   
         }finally{
                try {
                    this.cerrarConexion();
                } catch (Exception e) {
                    Logger.getLogger(competenciasVo.class.getName()).log(Level.SEVERE, null,e);             
                } 
                return compVo;
                } 
    }
     
   public ArrayList<competenciasVo> Listar ( ){
       
          ArrayList<competenciasVo> ListarCompetencias = new ArrayList<>();
         try {
             conexion = this.obteneConexion();
             sql="select * from competencias";
             puente =  conexion.prepareStatement(sql);
             mensajero = puente.executeQuery();
              while (mensajero.next()) {                
                competenciasVo  compVo = new competenciasVo(mensajero.getString(1), mensajero.getString(2));
                ListarCompetencias.add(compVo);           
            }
         } catch (Exception e) {
             Logger.getLogger(competenciasVo.class.getName()).log(Level.SEVERE, null,e);                   
         }finally{
                try {
                    this.cerrarConexion();
                } catch (Exception e) {
                    Logger.getLogger(competenciasVo.class.getName()).log(Level.SEVERE, null,e);             
                } 
                return ListarCompetencias;
                }
    }
    
   
    
}
