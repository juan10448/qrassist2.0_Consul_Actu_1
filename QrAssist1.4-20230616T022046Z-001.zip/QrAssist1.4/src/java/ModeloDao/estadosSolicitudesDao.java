/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloDao;

import ModeloVo.estadosSolicitudesVo;
import Util.CRUD;
import Util.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class estadosSolicitudesDao extends ConexionBD  {
    
    
    
    public estadosSolicitudesDao() {
    }

    private Connection conexion;
    private PreparedStatement puente;
    private ResultSet mensajero;
    private boolean operacion = false;
    private String sql;
    private String idEstaSo="", nomEstaSo="";


    public estadosSolicitudesDao(estadosSolicitudesVo estSoVo) {

        super();

        try {
            conexion = this.obteneConexion();
            idEstaSo= estSoVo.getIdEstaSo();
            nomEstaSo = estSoVo.getNomEstaSo();

        } catch (Exception e) {

         
            Logger.getLogger(estadosSolicitudesDao.class.getName()).log(Level.SEVERE, null, e);
        }

    }

   

    
    
      public ArrayList<estadosSolicitudesVo> Listar ( ){
       
          ArrayList<estadosSolicitudesVo> ListarSolicitudes = new ArrayList<>();
         try {
             conexion = this.obteneConexion();
             sql="select * from estadossolicitudes";
             puente =  conexion.prepareStatement(sql);
             mensajero = puente.executeQuery();
              while (mensajero.next()) {                
                estadosSolicitudesVo  estaSoVO = new estadosSolicitudesVo(mensajero.getString(1),mensajero.getString(2));
                ListarSolicitudes.add(estaSoVO);           
            }
         } catch (Exception e) {
             Logger.getLogger(estadosSolicitudesVo.class.getName()).log(Level.SEVERE, null,e);                   
         }finally{
                try {
                    this.cerrarConexion();
                } catch (Exception e) {
                    Logger.getLogger(estadosSolicitudesVo.class.getName()).log(Level.SEVERE, null,e);             
                } 
                return ListarSolicitudes;}   
         
         
    }
         
}     

    
