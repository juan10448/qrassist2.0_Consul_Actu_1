/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloDao;

import ModeloVo.asociacionUsuariosVo;
import Util.CRUD;
import Util.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author juans
 */
public class asociacionUsuariosDao extends ConexionBD implements CRUD  {

    public asociacionUsuariosDao() {
    }
   
    
     private Connection conexion;
    private PreparedStatement puente;
    private ResultSet mensajero;
    private boolean operacion = false;
    private String sql;
    private String idAsoUsu="", idFicha="", numDoc="";
    
   public asociacionUsuariosDao(asociacionUsuariosVo proVO) {

        super();
        try {
            conexion = this.obteneConexion();
            idAsoUsu = proVO.getIdAsoUsu();
            idFicha = proVO.getIdFicha();
            numDoc = proVO.getNumDoc();
   
            
        } catch (Exception e) {
            Logger.getLogger(asociacionUsuariosVo.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    @Override
    public boolean agregar() {
    try 
        {
            sql = "insert into asociacionUsuarios (idFicha, numDoc ) values (?, ?)";
            puente = conexion.prepareStatement(sql);
            puente.setString(1, idFicha);
            puente.setString(2, numDoc);
            puente.executeUpdate();
            operacion = true ;
        } catch (Exception e)
        {
            Logger.getLogger (asociacionUsuariosDao.class.getName()).log(Level.SEVERE,null,e);

        }finally{
            try {
                this.cerrarConexion();
            } catch (Exception e) {
                Logger.getLogger(asociacionUsuariosDao.class.getName()).log(Level.SEVERE,null,e);
            }
        }
        return operacion;    }

    @Override
    public boolean actualizar() {
    try 
        {
            sql = "update asociacionusuarios set idFicha=? where numDoc=?";
            puente = conexion.prepareStatement(sql);
            puente.setString(1, idFicha);
            puente.setString(2, numDoc);        
            puente.executeUpdate();
            operacion = true;
     
        } catch (Exception e)
        {
             Logger.getLogger(asociacionUsuariosDao.class.getName()).log(Level.SEVERE,null,e);
        }finally{
            try {
                this.cerrarConexion();
            } catch (Exception e) {
                Logger.getLogger(asociacionUsuariosDao.class.getName()).log(Level.SEVERE,null,e);
            }
        }
        return operacion;    }

    @Override
    public boolean eliminar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
     public asociacionUsuariosVo consultarAsousua(String id){
         asociacionUsuariosVo proVO = null;
         try {
             conexion = this.obteneConexion();
             sql="select * from asociacionusuarios where numDoc = ?";
             puente =  conexion.prepareStatement(sql);
             puente.setString(1, id);
             mensajero = puente.executeQuery();
             while(mensajero.next()){
                 proVO = new asociacionUsuariosVo(id, mensajero.getString(2), mensajero.getString(3));
             }  
         } catch (Exception e) {
             Logger.getLogger(asociacionUsuariosVo.class.getName()).log(Level.SEVERE, null,e);                   
         }finally{
                try {
                    this.cerrarConexion();
                } catch (Exception e) {
                    Logger.getLogger(asociacionUsuariosVo.class.getName()).log(Level.SEVERE, null,e);             
                } 
                return proVO;
                  } 
    }
     
   public ArrayList<asociacionUsuariosVo> Listar ( ){
       
          ArrayList<asociacionUsuariosVo> Listarasociacionusuarios = new ArrayList<>();
         try {
             conexion = this.obteneConexion();
             sql="select * from asociacionusuarios";
             puente =  conexion.prepareStatement(sql);
             mensajero = puente.executeQuery();
              while (mensajero.next()) {                
                asociacionUsuariosVo  proVO = new asociacionUsuariosVo(mensajero.getString(1), mensajero.getString(2),  mensajero.getString(3));
                Listarasociacionusuarios.add(proVO);           
            }
         } catch (Exception e) {
             Logger.getLogger(asociacionUsuariosVo.class.getName()).log(Level.SEVERE, null,e);                   
         }finally{
                try {
                    this.cerrarConexion();
                } catch (Exception e) {
                    Logger.getLogger(asociacionUsuariosVo.class.getName()).log(Level.SEVERE, null,e);             
                } 
                return Listarasociacionusuarios;
                }
    }
    
}
