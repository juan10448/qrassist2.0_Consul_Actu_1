/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloDao;

import ModeloVo.asociacionCompetenciasVo;
import ModeloVo.fichasVo;
import Util.CRUD;
import Util.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class asociacionCompetenciasDao extends ConexionBD implements CRUD{

    private Connection conexion;
    private PreparedStatement puente;
    private ResultSet mensajero;
    private boolean operacion = false;
    private String sql;
    private String idAsoComp = "", idFicha = "", idComp = "", numDoc = "", nomComp= "";

    public asociacionCompetenciasDao() {
    }

    public asociacionCompetenciasDao(asociacionCompetenciasVo asoCoVo) {

        super();

        try {
            conexion = this.obteneConexion();
            idAsoComp = asoCoVo.getIdAsoComp();
            idFicha = asoCoVo.getIdFicha();
            idComp = asoCoVo.getIdComp();
            numDoc = asoCoVo.getNumDoc();
        } catch (Exception e) {
            Logger.getLogger(asociacionCompetenciasDao.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    @Override
    public boolean agregar() {
    try 
        {
            sql = "insert into asociacioncompetencias (idFicha, idComp, numDoc ) values (?,?,?)";
            puente = conexion.prepareStatement(sql);
            puente.setString(1, idFicha);
            puente.setString(2, idComp);
            puente.setString(3, numDoc);
            puente.executeUpdate();
            operacion = true ;
        } catch (Exception e)
        {
            Logger.getLogger (fichasDao.class.getName()).log(Level.SEVERE,null,e);

        }finally{
            try {
                this.cerrarConexion();
            } catch (Exception e) {
                Logger.getLogger(fichasDao.class.getName()).log(Level.SEVERE,null,e);
            }
        }
        return operacion;    }

    @Override
    public boolean eliminar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar() {
    try 
        {
            sql = "update asociacioncompetencias set idFicha=?, idComp=? where numDoc=?";
            puente = conexion.prepareStatement(sql);
            puente.setString(1, idFicha);
            puente.setString(2, idComp);
            puente.setString(3, numDoc);
            
            puente.executeUpdate();
            operacion = true;
     
        } catch (Exception e)
        {
             Logger.getLogger(fichasDao.class.getName()).log(Level.SEVERE,null,e);
        }finally{
            try {
                this.cerrarConexion();
            } catch (Exception e) {
                Logger.getLogger(fichasDao.class.getName()).log(Level.SEVERE,null,e);
            }
        }
        return operacion;      }
    
    public asociacionCompetenciasVo consultarAsociacionCompetenciasFichas(String id){
         asociacionCompetenciasVo asoCoVo = null;
         try {
             conexion = this.obteneConexion();
             sql="SELECT * FROM vista_asociacioncompetencias where idficha=?";         
             puente =  conexion.prepareStatement(sql);
             puente.setString(1, id);
             mensajero = puente.executeQuery();
             while(mensajero.next()){
                 asoCoVo = new asociacionCompetenciasVo(id, mensajero.getString(2), mensajero.getString(3), mensajero.getString(4),  mensajero.getString(5));
             }  
         } catch (Exception e) {
             Logger.getLogger(asociacionCompetenciasVo.class.getName()).log(Level.SEVERE, null,e);                   
         }finally{
                try {
                    this.cerrarConexion();
                } catch (Exception e) {
                    Logger.getLogger(asociacionCompetenciasVo.class.getName()).log(Level.SEVERE, null,e);             
                } 
                return asoCoVo;
                  } 
    }
     
   public ArrayList<asociacionCompetenciasVo> Listar ( ){
       
          ArrayList<asociacionCompetenciasVo> ListarAsociacionCompetencias = new ArrayList<>();
         try {
             conexion = this.obteneConexion();
             sql="select * from vista_asociacioncompetencias";
             puente =  conexion.prepareStatement(sql);
             mensajero = puente.executeQuery();
              while (mensajero.next()) {                
                asociacionCompetenciasVo  asoCoVo = new asociacionCompetenciasVo(mensajero.getString(1), mensajero.getString(2), mensajero.getString(3), mensajero.getString(4), mensajero.getString(5));
                ListarAsociacionCompetencias.add(asoCoVo);           
            }
         } catch (Exception e) {
             Logger.getLogger(asociacionCompetenciasVo.class.getName()).log(Level.SEVERE, null,e);                   
         }finally{
                try {
                    this.cerrarConexion();
                } catch (Exception e) {
                    Logger.getLogger(asociacionCompetenciasVo.class.getName()).log(Level.SEVERE, null,e);             
                } 
                return ListarAsociacionCompetencias;
                }
    }
    

}
